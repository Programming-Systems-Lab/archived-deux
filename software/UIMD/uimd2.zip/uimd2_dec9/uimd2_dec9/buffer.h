#ifndef __BUFFER_H__
#define __BUFFER_H__

#define _MULTI_THREADED
#include <pthread.h>
#include <linux/uinput.h>

#endif
